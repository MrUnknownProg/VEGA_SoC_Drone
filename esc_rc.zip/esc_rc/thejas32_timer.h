#ifndef THEJAS32_TIMER_H
#define THEJAS32_TIMER_H

/*
 * THEJAS32 TIMER0 register map
 * Base address: 0x10000A00 (from official THEJAS32 address map)
 */
#define TIMER0_BASE             0x10000A00UL
#define TIMER1_BASE             0x10000A14UL
#define TIMER2_BASE             0x10000A28UL

/* Register offsets */
#define TIMER_LOAD_OFF          0x00    /* Load value = period          */
#define TIMER_VALUE_OFF         0x04    /* Current counter (read only)  */
#define TIMER_CONTROL_OFF       0x08    /* Control register             */
#define TIMER_EOI_OFF           0x0C    /* End of interrupt clear       */
#define TIMER_STATUS_OFF        0x10    /* Interrupt status             */

/* TIMER0 register access */
#define TIMER0_LOAD     (*((volatile unsigned int*)(TIMER0_BASE + TIMER_LOAD_OFF)))
#define TIMER0_VALUE    (*((volatile unsigned int*)(TIMER0_BASE + TIMER_VALUE_OFF)))
#define TIMER0_CONTROL  (*((volatile unsigned int*)(TIMER0_BASE + TIMER_CONTROL_OFF)))
#define TIMER0_EOI      (*((volatile unsigned int*)(TIMER0_BASE + TIMER_EOI_OFF)))
#define TIMER0_STATUS   (*((volatile unsigned int*)(TIMER0_BASE + TIMER_STATUS_OFF)))

/* Combined timer interrupt registers */
#define TIMERS_INTSTATUS (*((volatile unsigned int*)(0x10000AA0UL)))
#define TIMERS_EOI       (*((volatile unsigned int*)(0x10000AA4UL)))
#define TIMERS_RAWSTATUS (*((volatile unsigned int*)(0x10000AA8UL)))

/* Control register bit masks */
#define TIMER_ENABLE        (1 << 7)    /* 1 = running, 0 = stopped     */
#define TIMER_INTR_ENABLE   (1 << 5)    /* 1 = interrupt enabled        */
#define TIMER_MODE_PERIODIC (1 << 1)    /* 1 = periodic, 0 = one-shot   */
#define TIMER_SIZE_32BIT    (1 << 0)    /* 1 = 32-bit mode              */

/* Function declarations */
void timer0_init(unsigned int period_ms,
                 unsigned long clock_hz,
                 void (*callback)(void));
void timer0_stop(void);

#endif
