/*
 * thejas32_timer.c
 *
 * TIMER0 driver for THEJAS32 using VEGA SDK interrupt system.
 *
 * How it works:
 *   TIMER0 counts down from LOAD to 0 at CPU clock speed.
 *   When it hits 0 it fires an interrupt through PLIC.
 *   VEGA SDK interrupt_handler() dispatches to timer0_isr().
 *   timer0_isr() clears the interrupt and calls user callback.
 *
 * This is equivalent to CLINT on standard RISC-V chips.
 * CLINT fires directly into CPU — TIMER0 fires through PLIC.
 * End result is the same: guaranteed periodic interrupt.
 *
 * TIMER_0_IRQ = 7 (defined in interrupt.h from VEGA SDK)
 */

#include "thejas32_timer.h"
#include "interrupt.h"
#include "stdlib.h"

/* User callback function pointer — set by timer0_init() */
static void (*g_timer0_callback)(void) = 0;

/* ============================================================
 *  TIMER0 ISR
 *
 *  Called automatically by VEGA BSP interrupt dispatcher
 *  when TIMER0 fires. This happens every period_ms.
 *
 *  Rules for ISRs:
 *    1. Clear interrupt FIRST before doing any work
 *    2. Keep it short — do not call slow functions here
 *    3. All variables shared with main must be volatile
 * ============================================================ */
void timer0_isr(void)
{
    /* Clear TIMER0 interrupt — must do this first */
    /* Reading EOI register clears the interrupt flag */
    volatile unsigned int dummy = TIMER0_EOI;
    (void)dummy;

    /* Clear combined timers interrupt status */
    dummy = TIMERS_EOI;
    (void)dummy;

    /* Call user function — e.g. pid_10ms_tick() */
    if (g_timer0_callback)
        g_timer0_callback();
}

/* ============================================================
 *  TIMER0 INIT
 *
 *  period_ms  — how often to fire (1 = 1ms, 10 = 10ms etc)
 *  clock_hz   — CPU clock speed (38707200 for THEJAS32)
 *  callback   — function to call every period_ms
 *
 *  Uses VEGA SDK functions:
 *    irq_register_handler() — registers our ISR
 *    interrupt_enable()     — enables in PLIC
 *    enable_irq()           — enables in CPU
 *
 *  No direct PLIC register access needed — SDK handles it.
 * ============================================================ */
void timer0_init(unsigned int period_ms,
                 unsigned long clock_hz,
                 void (*callback)(void))
{
    unsigned int load_val;

    /* Store callback */
    g_timer0_callback = callback;

    /*
     * Calculate load value
     * TIMER0 decrements every CPU clock cycle
     * load = (clocks per ms) * period_ms - 1
     *
     * At 38707200 Hz:
     *   1ms  : load = 38707200/1000 * 1  - 1 = 38706
     *   10ms : load = 38707200/1000 * 10 - 1 = 387071
     *   1ms is equivalent to CLINT at 1000Hz tick rate
     */
    load_val = (unsigned int)((clock_hz / 1000UL) * (unsigned long)period_ms) - 1;

    /* Stop timer before reconfiguring */
    TIMER0_CONTROL = 0;

    /* Load the period value */
    TIMER0_LOAD = load_val;

    /*
     * Register ISR with VEGA SDK interrupt system
     * TIMER_0_IRQ = 7 (from interrupt.h)
     * SDK maintains an interrupt vector table
     * When TIMER0 fires, SDK calls timer0_isr()
     */
    irq_register_handler(TIMER_0_IRQ, timer0_isr);

    /* Enable TIMER0 interrupt in PLIC via SDK */
    interrupt_enable(TIMER_0_IRQ);

    /* Enable global machine-mode interrupts in CPU */
    enable_irq();

    /*
     * Start timer with all settings:
     *   TIMER_ENABLE        = start counting
     *   TIMER_INTR_ENABLE   = fire interrupt when done
     *   TIMER_MODE_PERIODIC = reload and repeat forever
     *   TIMER_SIZE_32BIT    = use full 32-bit counter
     */
    TIMER0_CONTROL = TIMER_ENABLE
                   | TIMER_INTR_ENABLE
                   | TIMER_MODE_PERIODIC
                   | TIMER_SIZE_32BIT;
}

/* ============================================================
 *  TIMER0 STOP
 *  Call this to stop the timer — e.g. during calibration
 * ============================================================ */
void timer0_stop(void)
{
    TIMER0_CONTROL = 0;
}
