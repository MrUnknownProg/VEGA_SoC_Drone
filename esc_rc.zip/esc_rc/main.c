#include "include/pwmc.h"
#include "include/ibus.h"
#include "include/gpio.h"
#include "include/stdlib.h"
#include "include/config.h"
#include "include/debug_uart.h"

// --- HARDWARE CALIBRATION CONSTANTS ---
#define PWM_CLK_FREQ        40000000UL 
#define ESC_PERIOD_TICKS    800000UL     // 20ms at 40MHz
#define CORRECTION_US       48           // Your verified offset

// --- MOTOR MAPPING ---
#define MOTOR_FL            0
#define MOTOR_FR            1
#define MOTOR_RL            2
#define MOTOR_RR            3

// --- RC SETTINGS ---
#define THROTTLE_CH         2            // iBUS Left Stick Up/Down
#define ESC_MIN_US          1000
#define ESC_MAX_US          2000

// 1 = Calibrate with RC (Direct pass-through), 0 = Normal Flight Mode
#define ESC_CALIBRATION_MODE    1

/* ============================================================
 * CALIBRATED TICK CONVERSION
 * Uses your verified 40MHz + 48us logic
 * ============================================================ */
unsigned int get_calibrated_ticks(unsigned int us) {
    unsigned int adjusted_us = us + CORRECTION_US;
    return (unsigned int)(((unsigned long long)adjusted_us * PWM_CLK_FREQ) / 1000000ULL);
}

/* ============================================================
 * SET SPEED ON ALL 4 MOTORS (CLEAN PWM)
 * ============================================================ */
void esc_set_all(unsigned int us) {
    if (us < ESC_MIN_US) us = ESC_MIN_US;
    if (us > ESC_MAX_US) us = ESC_MAX_US;

    unsigned int final_ticks = get_calibrated_ticks(us);

    for(int ch = 0; ch < 4; ch++) {
        PWMC_Set_OnOffTime(ch, final_ticks);
        // Force Continuous Mode and clear RepeatCount to fix fragmentation
        PWMCreg(ch).Control.word = (PWM_CONTINUOUS_MODE << 0); 
        PWMC_Set_Period(ch, ESC_PERIOD_TICKS);
    }
    PWMC_Enable();
}

/* ============================================================
 * MODE 1: RC-BASED CALIBRATION
 * Directly passes RC stick to ESCs for High/Low calibration
 * ============================================================ */
void esc_rc_calibrate(unsigned short *rc_values) {
    printf("\r\n--- RC CALIBRATION MODE ---\r\n");
    printf("1. Stick MAX -> Plug in LiPo\r\n");
    printf("2. Wait for beeps -> Stick MIN\r\n");

    while (1) {
        if (ibus_read(rc_values)) {
            unsigned int thr = rc_values[THROTTLE_CH];
            esc_set_all(thr);
            
            static int p_cnt = 0;
            if (p_cnt++ > 1000) {
                printf("Calibrating... Stick: %u us\r", thr);
                p_cnt = 0;
            }
        }
    }
}

/* ============================================================
 * NORMAL ARMING SEQUENCE
 * ============================================================ */
void esc_arm(void) {
    printf("\r\n Arming ESCs (3s)...\r\n");
    for (int i = 3; i > 0; i--) {
        esc_set_all(ESC_MIN_US);
        printf(" %d...\r\n", i);
        // Using a simple loop delay if delay_ms is unavailable
        for(volatile int d=0; d<10000000; d++); 
    }
    printf(" ESCs Armed!\r\n");
}

/* ============================================================
 * MAIN CONTROL LOOP
 * ============================================================ */
void main(void) {
    unsigned short rc_values[IBUS_NUM_CHANNELS] = {1000};
    
    ibus_init();
    
    // Safety: Set all to 1000us immediately
    esc_set_all(ESC_MIN_US);

    printf("\r\n=== Trisul-SoC RC/ESC System (40MHz) ===\r\n");

#if ESC_CALIBRATION_MODE == 1
    esc_rc_calibrate(rc_values);
#else
    esc_arm();

    while (1) {
        if (ibus_read(rc_values)) {
            unsigned int thr = rc_values[THROTTLE_CH];

            // Safety Failsafe: if RC out of range, set MIN
            if (thr >= 1000 && thr <= 2000) {
                esc_set_all(thr);
            } else {
                esc_set_all(ESC_MIN_US);
            }

            // Monitor Output
            static int m_cnt = 0;
            if (m_cnt++ > 500) {
                printf("THR: %u us | Ticks: %u \r", thr, get_calibrated_ticks(thr));
                m_cnt = 0;
            }
        }
    }
#endif
}