#include "i2c_api.h"
#include "debug_uart.h"
#include <stdio.h>

#define ISM_ADDR 0x6B
#define MMC_ADDR 0x30

void print_string(char *str) {
    while (*str) tx_uart(*str++);
}

void write_reg(unsigned char addr, unsigned char reg, unsigned char val) {
    i2c_beginTransmission(addr);
    i2c_write(reg);
    i2c_write(val);
    i2c_endTransmission(1);
}

int main() {
    unsigned char buf[14];
    char msg[256];
    int loop_counter = 0;

    init_uart();
    i2c_init(0); 
    print_string("\r\n--- 9-DoF ROBUST TELEMETRY ---\r\n");

    // Initial Sensor Setup
    write_reg(ISM_ADDR, 0x10, 0x10); // Accel 12.5Hz
    write_reg(ISM_ADDR, 0x11, 0x10); // Gyro 12.5Hz
    
    // Hard Reset MMC
    write_reg(MMC_ADDR, 0x09, 0x10); 
    for(volatile int i=0; i<200000; i++);

    while (1) {
        // --- 1. ACCEL & GYRO (Reliable) ---
        i2c_beginTransmission(ISM_ADDR);
        i2c_write(0x22); 
        i2c_endTransmission(1);
        
        if (i2c_requestFrom(ISM_ADDR, 12, 1)) {
            for(int i=0; i<12; i++) buf[i] = i2c_read();
            int16_t gx = (int16_t)(buf[1] << 8 | buf[0]);
            int16_t gy = (int16_t)(buf[3] << 8 | buf[2]);
            int16_t gz = (int16_t)(buf[5] << 8 | buf[4]);
            int16_t ax = (int16_t)(buf[7] << 8 | buf[6]);
            int16_t ay = (int16_t)(buf[9] << 8 | buf[8]);
            int16_t az = (int16_t)(buf[11] << 10 | buf[10]);
            sprintf(msg, "G[%d, %d, %d] A[%d, %d, %d] ", gx, gy, gz, ax, ay, az);
            print_string(msg);
        }

        // --- 2. MAGNETOMETER (With Protection) ---
        // Every 5 loops, force a SET/RESET to clear magnetic saturation
        if (loop_counter % 5 == 0) {
            write_reg(MMC_ADDR, 0x09, 0x08); // SET
            for(volatile int i=0; i<50000; i++);
            write_reg(MMC_ADDR, 0x09, 0x04); // RESET
            for(volatile int i=0; i<50000; i++);
        }
        loop_counter++;

        // Trigger measurement
        write_reg(MMC_ADDR, 0x09, 0x01); 
        
        // Wait for ready with a HARD TIMEOUT to prevent CPU crash
        unsigned char status = 0;
        int timeout = 5000; 
        while (!(status & 0x01) && timeout-- > 0) {
            i2c_beginTransmission(MMC_ADDR);
            i2c_write(0x08); 
            i2c_endTransmission(1);
            i2c_requestFrom(MMC_ADDR, 1, 1);
            status = i2c_read();
        }

        if (timeout > 0) {
            i2c_beginTransmission(MMC_ADDR);
            i2c_write(0x00); 
            i2c_endTransmission(1);
            if (i2c_requestFrom(MMC_ADDR, 6, 1)) {
                uint32_t mx_u = ((uint32_t)i2c_read() << 8) | i2c_read();
                uint32_t my_u = ((uint32_t)i2c_read() << 8) | i2c_read();
                uint32_t mz_u = ((uint32_t)i2c_read() << 8) | i2c_read();
                sprintf(msg, "M[%ld, %ld, %ld]\r\n", (int32_t)mx_u-32768, (int32_t)my_u-32768, (int32_t)mz_u-32768);
                print_string(msg);
            }
        } else {
            print_string("M[STUCK]\r\n");
        }

        for (volatile int i = 0; i < 2000000; i++); 
    }
}