#include "i2c_api.h"
#include "debug_uart.h"
#include <stdio.h>
#include <math.h>
#include <stdint.h>

/* ================= ADDR ================= */
#define ISM_ADDR 0x6B
#define MMC_ADDR 0x30

#define RAD2DEG 57.295779f
#define DEG2RAD 0.0174533f

/* ================= MAHONY ================= */
float q[4] = {1,0,0,0};

float Kp = 2.0f;
float Ki = 0.05f;

float exInt=0, eyInt=0, ezInt=0;

float dt = 0.1f;

/* ================= UTILS ================= */
void print_string(char *str) {
    while (*str) tx_uart(*str++);
}

void write_reg(unsigned char addr, unsigned char reg, unsigned char val) {
    i2c_beginTransmission(addr);
    i2c_write(reg);
    i2c_write(val);
    i2c_endTransmission(1);
}

/* ================= NORMALIZE ================= */
void normalize_quat() {
    float norm = sqrtf(q[0]*q[0] + q[1]*q[1] + q[2]*q[2] + q[3]*q[3]);
    if(norm == 0) return;
    for(int i=0;i<4;i++) q[i] /= norm;
}

/* ================= MAIN ================= */
int main() {

    unsigned char buf[12];
    char msg[128];

    int loop_counter = 0;

    int16_t ax=0, ay=0, az=0;
    int16_t gx=0, gy=0, gz=0;

    float mx=0, my=0, mz=0;

    init_uart();
    i2c_init(0);

    print_string("\r\n--- MAHONY AHRS START ---\r\n");

    /* SENSOR INIT */
    write_reg(ISM_ADDR, 0x10, 0x10);
    write_reg(ISM_ADDR, 0x11, 0x10);

    write_reg(MMC_ADDR, 0x09, 0x10);
    for(volatile int i=0;i<200000;i++);

    while (1) {

        /* ===== IMU READ (UNCHANGED) ===== */
        i2c_beginTransmission(ISM_ADDR);
        i2c_write(0x22);
        i2c_endTransmission(1);

        if (i2c_requestFrom(ISM_ADDR, 12, 1)) {
            for(int i=0;i<12;i++) buf[i]=i2c_read();

            gx = (int16_t)(buf[1]<<8 | buf[0]);
            gy = (int16_t)(buf[3]<<8 | buf[2]);
            gz = (int16_t)(buf[5]<<8 | buf[4]);

            ax = (int16_t)(buf[7]<<8 | buf[6]);
            ay = (int16_t)(buf[9]<<8 | buf[8]);
            az = (int16_t)(buf[11]<<8 | buf[10]);
        }

        /* ===== MAG READ (UNCHANGED) ===== */
        if (loop_counter % 5 == 0) {
            write_reg(MMC_ADDR, 0x09, 0x08);
            for(volatile int i=0;i<50000;i++);
            write_reg(MMC_ADDR, 0x09, 0x04);
            for(volatile int i=0;i<50000;i++);
        }
        loop_counter++;

        write_reg(MMC_ADDR, 0x09, 0x01);

        uint8_t status=0;
        int timeout=5000;

        while (!(status & 0x01) && timeout-- > 0) {
            i2c_beginTransmission(MMC_ADDR);
            i2c_write(0x08);
            i2c_endTransmission(1);
            i2c_requestFrom(MMC_ADDR, 1, 1);
            status = i2c_read();
        }

        if(timeout > 0) {
            i2c_beginTransmission(MMC_ADDR);
            i2c_write(0x00);
            i2c_endTransmission(1);

            if(i2c_requestFrom(MMC_ADDR, 6, 1)) {
                uint32_t mx_u = ((uint32_t)i2c_read()<<8)|i2c_read();
                uint32_t my_u = ((uint32_t)i2c_read()<<8)|i2c_read();
                uint32_t mz_u = ((uint32_t)i2c_read()<<8)|i2c_read();

                mx = (float)((int32_t)mx_u - 32768);
                my = (float)((int32_t)my_u - 32768);
                mz = (float)((int32_t)mz_u - 32768);
            }
        }

        /* ===== SCALE ===== */
        float axf = ax / 16384.0f;
        float ayf = ay / 16384.0f;
        float azf = az / 16384.0f;

        float gxf = gx * 0.00875f * DEG2RAD;
        float gyf = gy * 0.00875f * DEG2RAD;
        float gzf = gz * 0.00875f * DEG2RAD;

        /* ===== NORMALIZE ACC ===== */
        float norm_a = sqrtf(axf*axf + ayf*ayf + azf*azf);
        int use_acc = 0;

        if(norm_a > 0.7f && norm_a < 1.3f) {
            axf/=norm_a; ayf/=norm_a; azf/=norm_a;
            use_acc = 1;
        }

        /* ===== NORMALIZE MAG ===== */
        float norm_m = sqrtf(mx*mx + my*my + mz*mz);
        if(norm_m > 0) {
            mx/=norm_m; my/=norm_m; mz/=norm_m;
        }

        float qw=q[0], qx=q[1], qy=q[2], qz=q[3];

        /* ===== EST GRAVITY ===== */
        float vx = 2*(qx*qz - qw*qy);
        float vy = 2*(qw*qx + qy*qz);
        float vz = qw*qw - qx*qx - qy*qy + qz*qz;

        /* ===== EST MAG ===== */
        float hx = 2*mx*(0.5f - qy*qy - qz*qz) +
                   2*my*(qx*qy - qw*qz) +
                   2*mz*(qx*qz + qw*qy);

        float hy = 2*mx*(qx*qy + qw*qz) +
                   2*my*(0.5f - qx*qx - qz*qz) +
                   2*mz*(qy*qz - qw*qx);

        /* ===== ERROR ===== */
        float ex=0, ey=0, ez=0;

        if(use_acc) {
            ex += (ayf*vz - azf*vy);
            ey += (azf*vx - axf*vz);
            ez += (axf*vy - ayf*vx);
        }

        float ez_mag = (my*hx - mx*hy);
        ez += ez_mag;

        /* ===== INTEGRAL ===== */
        exInt += ex * Ki;
        eyInt += ey * Ki;
        ezInt += ez * Ki;

        /* ===== APPLY ===== */
        gxf += Kp*ex + exInt;
        gyf += Kp*ey + eyInt;
        gzf += Kp*ez + ezInt;

        /* ===== INTEGRATE ===== */
        q[0] += (-qx*gxf - qy*gyf - qz*gzf)*0.5f*dt;
        q[1] += ( qw*gxf + qy*gzf - qz*gyf)*0.5f*dt;
        q[2] += ( qw*gyf - qx*gzf + qz*gxf)*0.5f*dt;
        q[3] += ( qw*gzf + qx*gyf - qy*gxf)*0.5f*dt;

        normalize_quat();

        /* ===== EULER ===== */
        float roll  = atan2f(2*(q[0]*q[1]+q[2]*q[3]), 1-2*(q[1]*q[1]+q[2]*q[2]));
        float pitch = asinf(2*(q[0]*q[2]-q[3]*q[1]));
        float yaw   = atan2f(2*(q[0]*q[3]+q[1]*q[2]), 1-2*(q[2]*q[2]+q[3]*q[3]));

        sprintf(msg,"R:%d P:%d Y:%d\r\n",
            (int)(roll*RAD2DEG),
            (int)(pitch*RAD2DEG),
            (int)(yaw*RAD2DEG)
        );
        print_string(msg);

        for (volatile int i=0;i<2000000;i++);
    }
}