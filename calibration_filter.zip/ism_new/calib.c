/*****************************************************************************
 * calibrate.c — IMU + Magnetometer Calibration
 *
 * Platform:  THEJAS32 / Trisul32
 * UART0:     0x10000100
 * I2C0:      0x10000800
 * Sensors:   ISM330DHCX + MMC5983MA
 *
 * Sequence matches Mission Planner exactly:
 *
 *   PHASE 1 — 6 STILL POSITIONS (accel + mag samples, hold still)
 *     Position 1 — LEVEL        (flat, top up)
 *     Position 2 — NOSE UP      (front up)
 *     Position 3 — NOSE DOWN    (back up)
 *     Position 4 — LEFT UP      (left side up)
 *     Position 5 — RIGHT UP     (right side up)
 *     Position 6 — BOTTOM UP    (upside down)
 *
 *   PHASE 2 — ROTATE 360 (mag only, slow rotation all directions)
 *
 * OUTPUT:
 *   Accel offsets  — from 6 still positions
 *   Mag offsets    — from 6 still positions + rotation
 *   Copy printed #define values into mahony_cal.c
 *****************************************************************************/

#include <stdint.h>
#include <stdio.h>
#include "i2c_api.h"
#include "include/debug_uart.h"

/* ═══════════════════════════════════════════════════════════════
 * UART0 — 0x10000100
 * ═══════════════════════════════════════════════════════════════ */
#define UART0_BASE        0x10000100UL
#define UART_DR           (*(volatile uint32_t *)(UART0_BASE + 0x00))
#define UART_LSR          (*(volatile uint32_t *)(UART0_BASE + 0x14))
#define UART_LSR_TX_EMPTY (1u << 5)
#define UART_LSR_RX_READY (1u << 0)

void init_uart(void) {}

void tx_uart(unsigned char c) {
    while (!(UART_LSR & UART_LSR_TX_EMPTY));
    UART_DR = (uint32_t)c;
}

unsigned char rx_uart(void) {
    while (!(UART_LSR & UART_LSR_RX_READY));
    return (unsigned char)UART_DR;
}

int _write(int fd, const char *buf, int count) {
    (void)fd;
    for (int i = 0; i < count; i++) tx_uart((unsigned char)buf[i]);
    return count;
}

static void wait_for_enter(void) {
    unsigned char c = 0;
    while (c != '\r' && c != '\n') c = rx_uart();
}

static int check_enter(void) {
    if (UART_LSR & UART_LSR_RX_READY) {
        unsigned char c = (unsigned char)UART_DR;
        if (c == '\r' || c == '\n') return 1;
    }
    return 0;
}

/* ═══════════════════════════════════════════════════════════════
 * I2C + sensor defines
 * ═══════════════════════════════════════════════════════════════ */
#define I2C_BUS           0

#define ISM_ADDR          0x6B
#define ISM_WHO_AM_I      0x0F
#define ISM_CTRL1_XL      0x10
#define ISM_CTRL2_G       0x11
#define ISM_CTRL3_C       0x12
#define ISM_OUTX_L_G      0x22

#define MMC_ADDR          0x30
#define MMC_XOUT0         0x00
#define MMC_STATUS        0x08
#define MMC_CTRL0         0x09
#define MMC_CTRL1         0x0A
#define MMC_WHO_AM_I      0x2F
#define MMC_TM_M          0x01
#define MMC_SET           0x08
#define MMC_MEAS_DONE     0x01

/* Samples per still position */
#define SAMPLES_PER_POS   100
/* Minimum samples during rotation phase */
#define MIN_ROT_SAMPLES   200
/* Number of still positions */
#define NUM_POSITIONS       6

/* ═══════════════════════════════════════════════════════════════
 * Helpers
 * ═══════════════════════════════════════════════════════════════ */
static void local_sleep(volatile uint32_t n) { while (n--) __asm__("nop"); }

static void i2c_write_reg(uint8_t addr, uint8_t reg, uint8_t val) {
    i2c_beginTransmission(addr);
    i2c_write(reg);
    i2c_write(val);
    i2c_endTransmission(1);
    local_sleep(10000);
}

/* STOP + new START — matches peer code that worked on I2C0 */
static void i2c_read_regs(uint8_t addr, uint8_t reg, uint8_t *buf, uint8_t len) {
    i2c_beginTransmission(addr);
    i2c_write(reg);
    i2c_endTransmission(1);
    if (i2c_requestFrom(addr, len, 1))
        for (uint8_t i = 0; i < len; i++) buf[i] = (uint8_t)i2c_read();
}

static int32_t isqrt32(int32_t x) {
    if (x <= 0) return 0;
    int32_t r = x >> 1;
    if (r == 0) return 1;
    for (int i = 0; i < 8; i++) r = (r + x/r) >> 1;
    return r;
}

/* ═══════════════════════════════════════════════════════════════
 * Sensor init
 * ═══════════════════════════════════════════════════════════════ */
static uint8_t ism330_init(void) {
    uint8_t id;
    i2c_read_regs(ISM_ADDR, ISM_WHO_AM_I, &id, 1);
    if (id != 0x6Bu) return 0;
    i2c_write_reg(ISM_ADDR, ISM_CTRL3_C,  0x04);  /* IF_INC=1       */
    i2c_write_reg(ISM_ADDR, ISM_CTRL1_XL, 0x4A);  /* 104Hz ±4g      */
    i2c_write_reg(ISM_ADDR, ISM_CTRL2_G,  0x4C);  /* 104Hz 500dps   */
    local_sleep(200000);
    return 1;
}

static uint8_t mmc5983_init(void) {
    uint8_t id;
    i2c_read_regs(MMC_ADDR, MMC_WHO_AM_I, &id, 1);
    if (id != 0x30u) return 0;
    i2c_write_reg(MMC_ADDR, MMC_CTRL0, MMC_SET);
    local_sleep(10000);
    i2c_write_reg(MMC_ADDR, MMC_CTRL1, 0x00);
    return 1;
}

static void read_accel(int16_t *ax, int16_t *ay, int16_t *az) {
    uint8_t raw[12];
    i2c_read_regs(ISM_ADDR, ISM_OUTX_L_G, raw, 12);
    *ax = (int16_t)((raw[7] <<8)|raw[6]);
    *ay = (int16_t)((raw[9] <<8)|raw[8]);
    *az = (int16_t)((raw[11]<<8)|raw[10]);
}

/* SET/RESET counter — refresh sensor bridge every 50 reads
 * same as peer code that used loop_counter % 5               */
static int mag_read_count = 0;

static uint8_t read_mag(int32_t *mx, int32_t *my, int32_t *mz) {
    /* Periodic SET/RESET — prevents bridge drift and keeps
     * sensitivity correct. Peer code did this every 5 loops.
     * We do it every 50 reads (less I2C traffic overhead).   */
    mag_read_count++;
    if (mag_read_count % 50 == 1) {
        /* SET pulse — aligns magnetic domains */
        i2c_write_reg(MMC_ADDR, 0x09, 0x08);
        local_sleep(50000);
        /* RESET pulse — flips domains, average of SET+RESET
         * cancels sensor offset and temperature drift        */
        i2c_write_reg(MMC_ADDR, 0x09, 0x10);
        local_sleep(50000);
    }

    /* Trigger single measurement */
    i2c_write_reg(MMC_ADDR, MMC_CTRL0, MMC_TM_M);

    /* Poll Meas_M_Done */
    uint32_t timeout = 100000;
    uint8_t status = 0;
    while (timeout--) {
        i2c_read_regs(MMC_ADDR, MMC_STATUS, &status, 1);
        if (status & MMC_MEAS_DONE) break;
        local_sleep(50);
    }
    if (!(status & MMC_MEAS_DONE)) return 0;

    /* Read X — 0x00, 0x01 */
    uint8_t bx[2] = {0, 0};
    i2c_beginTransmission(MMC_ADDR);
    i2c_write(0x00);
    i2c_endTransmission(1);
    if (i2c_requestFrom(MMC_ADDR, 2, 1)) {
        bx[0] = (uint8_t)i2c_read();
        bx[1] = (uint8_t)i2c_read();
    }

    /* Read Y — 0x02, 0x03 */
    uint8_t by[2] = {0, 0};
    i2c_beginTransmission(MMC_ADDR);
    i2c_write(0x02);
    i2c_endTransmission(1);
    if (i2c_requestFrom(MMC_ADDR, 2, 1)) {
        by[0] = (uint8_t)i2c_read();
        by[1] = (uint8_t)i2c_read();
    }

    /* Read Z — 0x04, 0x05 */
    uint8_t bz[2] = {0, 0};
    i2c_beginTransmission(MMC_ADDR);
    i2c_write(0x04);
    i2c_endTransmission(1);
    if (i2c_requestFrom(MMC_ADDR, 2, 1)) {
        bz[0] = (uint8_t)i2c_read();
        bz[1] = (uint8_t)i2c_read();
    }

    *mx = (int32_t)(((uint32_t)bx[0]<<8) | bx[1]) - 32768;
    *my = (int32_t)(((uint32_t)by[0]<<8) | by[1]) - 32768;
    *mz = (int32_t)(((uint32_t)bz[0]<<8) | bz[1]) - 32768;
    return 1;
}

/* ═══════════════════════════════════════════════════════════════
 * PHASE 1 — 6 STILL POSITIONS
 *
 * For each position:
 *   - User holds board STILL in that orientation
 *   - Press Enter when stable
 *   - Collect SAMPLES_PER_POS samples of accel + mag
 *   - Track accel sum (for offset) and mag min/max
 *
 * Expected accel readings per position (at ±4g, 8192 LSB/g):
 *   LEVEL:      ax≈0    ay≈0    az≈+8192
 *   NOSE UP:    ax≈+8192 ay≈0   az≈0
 *   NOSE DOWN:  ax≈-8192 ay≈0   az≈0
 *   LEFT UP:    ax≈0    ay≈-8192 az≈0
 *   RIGHT UP:   ax≈0    ay≈+8192 az≈0
 *   BOTTOM UP:  ax≈0    ay≈0    az≈-8192
 * ═══════════════════════════════════════════════════════════════ */

static const char *pos_name[NUM_POSITIONS] = {
    "LEVEL      — flat on table, top facing UP",
    "NOSE UP    — front of board pointing UP",
    "NOSE DOWN  — front of board pointing DOWN",
    "LEFT UP    — left side of board pointing UP",
    "RIGHT UP   — right side of board pointing UP",
    "BOTTOM UP  — board upside down, bottom facing UP",
};

/* Expected gravity axis and sign per position for quality check
 * axis: 0=X 1=Y 2=Z,  sign: +1 or -1 */
static const int exp_axis[NUM_POSITIONS] = { 2,  0,  0,  1,  1,  2 };
static const int exp_sign[NUM_POSITIONS] = {+1, +1, -1, -1, +1, -1 };

static void phase1_still_positions(
    int32_t *off_ax, int32_t *off_ay, int32_t *off_az,
    int32_t *mx_min, int32_t *mx_max,
    int32_t *my_min, int32_t *my_max,
    int32_t *mz_min, int32_t *mz_max)
{
    /* Accel accumulator across all 6 faces */
    int64_t sum_ax[NUM_POSITIONS], sum_ay[NUM_POSITIONS], sum_az[NUM_POSITIONS];

    /* Init mag min/max */
    *mx_min= 2000000; *mx_max=-2000000;
    *my_min= 2000000; *my_max=-2000000;
    *mz_min= 2000000; *mz_max=-2000000;

    printf("\r\n╔══════════════════════════════════════════╗\r\n");
    printf(  "║   PHASE 1 — 6 STILL POSITIONS           ║\r\n");
    printf(  "║   Hold STILL in each position            ║\r\n");
    printf(  "║   Press Enter when stable                ║\r\n");
    printf(  "╚══════════════════════════════════════════╝\r\n");

    for (int pos = 0; pos < NUM_POSITIONS; pos++) {

        printf("\r\n--- Position %d / %d ---\r\n", pos+1, NUM_POSITIONS);
        printf("  %s\r\n", pos_name[pos]);
        printf("  Hold STILL then press Enter...\r\n");
        wait_for_enter();
        printf("  Collecting %d samples", SAMPLES_PER_POS);

        sum_ax[pos] = 0;
        sum_ay[pos] = 0;
        sum_az[pos] = 0;
        int mag_count = 0;

        for (int s = 0; s < SAMPLES_PER_POS; s++) {
            /* Accel */
            int16_t ax, ay, az;
            read_accel(&ax, &ay, &az);
            sum_ax[pos] += ax;
            sum_ay[pos] += ay;
            sum_az[pos] += az;

            /* Mag — read every 3 accel samples (mag is slower) */
            if (s % 3 == 0) {
                int32_t mx, my, mz;
                if (read_mag(&mx, &my, &mz)) {
                    if (mx < *mx_min) *mx_min = mx;
                    if (mx > *mx_max) *mx_max = mx;
                    if (my < *my_min) *my_min = my;
                    if (my > *my_max) *my_max = my;
                    if (mz < *mz_min) *mz_min = mz;
                    if (mz > *mz_max) *mz_max = mz;
                    mag_count++;
                }
            }

            if (s % 20 == 0) printf(".");
            local_sleep(300000);
        }
        printf(" done\r\n");

        /* Average accel for this position */
        int32_t avg_ax = (int32_t)(sum_ax[pos] / SAMPLES_PER_POS);
        int32_t avg_ay = (int32_t)(sum_ay[pos] / SAMPLES_PER_POS);
        int32_t avg_az = (int32_t)(sum_az[pos] / SAMPLES_PER_POS);

        printf("  Accel avg: X=%d Y=%d Z=%d\r\n", avg_ax, avg_ay, avg_az);
        printf("  Mag samples: %d\r\n", mag_count);

        /* Quality check — verify correct axis is near ±8192 */
        int32_t vals[3] = {avg_ax, avg_ay, avg_az};
        int32_t expected_val = exp_sign[pos] * 8192;
        int32_t actual_val   = vals[exp_axis[pos]];
        int32_t error        = actual_val - expected_val;
        if (error < 0) error = -error;

        if (error > 2000) {
            printf("  WARN: Board may not be in correct orientation\r\n");
            printf("  Expected axis %d ≈ %d, got %d\r\n",
                   exp_axis[pos], expected_val, actual_val);
            printf("  Redo this position? Press Enter to redo, any key+Enter to skip\r\n");
            unsigned char c = rx_uart();
            if (c == '\r' || c == '\n') {
                pos--;   /* repeat this position */
                continue;
            }
            wait_for_enter();
        } else {
            printf("  Position OK\r\n");
        }
    }

    /* ── Compute accel offsets from 6 faces ──
     * Each axis offset = average of +face and -face readings
     * X offset: average of NOSE_UP and NOSE_DOWN averages
     * Y offset: average of LEFT_UP and RIGHT_UP averages
     * Z offset: average of LEVEL and BOTTOM_UP averages         */
    int32_t ax_pos = (int32_t)(sum_ax[1] / SAMPLES_PER_POS); /* nose up   */
    int32_t ax_neg = (int32_t)(sum_ax[2] / SAMPLES_PER_POS); /* nose down */
    int32_t ay_neg = (int32_t)(sum_ay[3] / SAMPLES_PER_POS); /* left up   */
    int32_t ay_pos = (int32_t)(sum_ay[4] / SAMPLES_PER_POS); /* right up  */
    int32_t az_pos = (int32_t)(sum_az[0] / SAMPLES_PER_POS); /* level     */
    int32_t az_neg = (int32_t)(sum_az[5] / SAMPLES_PER_POS); /* bottom up */

    *off_ax = (ax_pos + ax_neg) / 2;
    *off_ay = (ay_pos + ay_neg) / 2;
    *off_az = (az_pos + az_neg) / 2;

    printf("\r\nAccel offsets computed from 6 faces:\r\n");
    printf("  off_ax = %d\r\n", *off_ax);
    printf("  off_ay = %d\r\n", *off_ay);
    printf("  off_az = %d\r\n", *off_az);
}

/* ═══════════════════════════════════════════════════════════════
 * PHASE 2 — ROTATE 360
 *
 * User rotates board slowly in all directions.
 * Collect mag data to find full min/max range.
 * Press Enter when done (accepted after MIN_ROT_SAMPLES).
 * ═══════════════════════════════════════════════════════════════ */
static void phase2_rotation(
    int32_t *mx_min, int32_t *mx_max,
    int32_t *my_min, int32_t *my_max,
    int32_t *mz_min, int32_t *mz_max)
{
    printf("\r\n╔══════════════════════════════════════════╗\r\n");
    printf(  "║   PHASE 2 — ROTATE 360                  ║\r\n");
    printf(  "║   Rotate board in ALL directions         ║\r\n");
    printf(  "║                                          ║\r\n");
    printf(  "║   Do these slowly one by one:            ║\r\n");
    printf(  "║   1. Spin flat clockwise                 ║\r\n");
    printf(  "║   2. Spin flat counter-clockwise         ║\r\n");
    printf(  "║   3. Nose up, spin around                ║\r\n");
    printf(  "║   4. Left side up, spin around           ║\r\n");
    printf(  "║   5. Figure-8 motion                     ║\r\n");
    printf(  "║                                          ║\r\n");
    printf(  "║   Z axis must go NEGATIVE — tilt nose    ║\r\n");
    printf(  "║   fully DOWN toward ground               ║\r\n");
    printf(  "║   Press Enter when done                  ║\r\n");
    printf(  "║   (accepted after %d samples)          ║\r\n", MIN_ROT_SAMPLES);
    printf(  "╚══════════════════════════════════════════╝\r\n");
    printf("\r\n  Press Enter to START rotating...\r\n");
    wait_for_enter();
    printf("  ROTATING NOW...\r\n");

    int rot_samples = 0;

    while (1) {
        if (rot_samples >= MIN_ROT_SAMPLES && check_enter()) break;

        int32_t mx, my, mz;
        if (read_mag(&mx, &my, &mz)) {
            if (mx < *mx_min) *mx_min = mx;
            if (mx > *mx_max) *mx_max = mx;
            if (my < *my_min) *my_min = my;
            if (my > *my_max) *my_max = my;
            if (mz < *mz_min) *mz_min = mz;
            if (mz > *mz_max) *mz_max = mz;
            rot_samples++;

            if (rot_samples % 50 == 0)
                printf("  [%d samples] X[%d,%d] Y[%d,%d] Z[%d,%d]\r\n",
                       rot_samples,
                       *mx_min, *mx_max,
                       *my_min, *my_max,
                       *mz_min, *mz_max);
        }
    }

    printf("  Rotation done: %d samples\r\n", rot_samples);
}

/* ═══════════════════════════════════════════════════════════════
 * Compute mag offsets from min/max
 * ═══════════════════════════════════════════════════════════════ */
static void compute_mag_offsets(
    int32_t mx_min, int32_t mx_max,
    int32_t my_min, int32_t my_max,
    int32_t mz_min, int32_t mz_max,
    int32_t *off_mx, int32_t *off_my, int32_t *off_mz,
    int32_t *scale_x, int32_t *scale_y, int32_t *scale_z)
{
    /* Hard-iron: centre of min/max */
    *off_mx = (mx_max + mx_min) / 2;
    *off_my = (my_max + my_min) / 2;
    *off_mz = (mz_max + mz_min) / 2;

    /* Soft-iron scale Q8 (256 = 1.0) */
    int32_t range_x = mx_max - mx_min;
    int32_t range_y = my_max - my_min;
    int32_t range_z = mz_max - mz_min;
    int32_t avg_range = (range_x + range_y + range_z) / 3;

    *scale_x = (range_x > 0) ? (avg_range * 256) / range_x : 256;
    *scale_y = (range_y > 0) ? (avg_range * 256) / range_y : 256;
    *scale_z = (range_z > 0) ? (avg_range * 256) / range_z : 256;

    printf("\r\nMag axis ranges:\r\n");
    printf("  X: min=%d max=%d range=%d\r\n", mx_min, mx_max, range_x);
    printf("  Y: min=%d max=%d range=%d\r\n", my_min, my_max, range_y);
    printf("  Z: min=%d max=%d range=%d\r\n", mz_min, mz_max, range_z);

    /* Soft-iron distortion check */
    int32_t max_r = range_x > range_y ? range_x : range_y;
    max_r = max_r > range_z ? max_r : range_z;
    int32_t min_r = range_x < range_y ? range_x : range_y;
    min_r = min_r < range_z ? min_r : range_z;
    if (min_r > 0) {
        int32_t dist = ((max_r - min_r) * 100) / min_r;
        printf("  Soft-iron distortion: %d%%%s\r\n", dist,
               dist > 30 ? " — WARN: motor/metal interference" : " — OK");
    }
}

/* ═══════════════════════════════════════════════════════════════
 * Print final results
 * ═══════════════════════════════════════════════════════════════ */
static void print_results(
    int32_t oax, int32_t oay, int32_t oaz,
    int32_t omx, int32_t omy, int32_t omz,
    int32_t sx,  int32_t sy,  int32_t sz)
{
    /* ── Section 1: Human readable summary ── */
    printf("\r\n========================================\r\n");
    printf("         CALIBRATION RESULTS\r\n");
    printf("========================================\r\n");

    printf("\r\nACCEL OFFSETS (raw LSB, +-4g scale):\r\n");
    printf("  X offset : %d\r\n", oax);
    printf("  Y offset : %d\r\n", oay);
    printf("  Z offset : %d\r\n", oaz);

    printf("\r\nMAG HARD-IRON OFFSETS (16-bit counts, centred at 32768):\r\n");
    printf("  X offset : %d\r\n", omx);
    printf("  Y offset : %d\r\n", omy);
    printf("  Z offset : %d\r\n", omz);

    printf("\r\nMAG SOFT-IRON SCALE (Q8, 256 = 1.0):\r\n");
    printf("  X scale  : %d  (%.3f)\r\n", sx, (float)sx / 256.0f);
    printf("  Y scale  : %d  (%.3f)\r\n", sy, (float)sy / 256.0f);
    printf("  Z scale  : %d  (%.3f)\r\n", sz, (float)sz / 256.0f);

    /* ── Section 2: How offsets are applied ── */
    printf("\r\n========================================\r\n");
    printf("  HOW TO APPLY IN mahony_cal.c:\r\n");
    printf("========================================\r\n");
    printf("  Accel (in sensor read, before scaling):\r\n");
    printf("    ax_raw -= ACCEL_OFF_X;\r\n");
    printf("    ay_raw -= ACCEL_OFF_Y;\r\n");
    printf("    az_raw -= ACCEL_OFF_Z;\r\n");
    printf("  Mag (after reading, before normalise):\r\n");
    printf("    mx = ((mx_raw - MAG_OFF_X) * MAG_SCALE_X) >> 8;\r\n");
    printf("    my = ((my_raw - MAG_OFF_Y) * MAG_SCALE_Y) >> 8;\r\n");
    printf("    mz = ((mz_raw - MAG_OFF_Z) * MAG_SCALE_Z) >> 8;\r\n");

    /* ── Section 3: Ready-to-paste #defines ── */
    printf("\r\n╔══════════════════════════════════════════╗\r\n");
    printf(  "║   PASTE INTO mahony_cal.c                ║\r\n");
    printf(  "╠══════════════════════════════════════════╣\r\n");
    printf(  "║                                          ║\r\n");
    printf(  "║  /* Accel offsets */                     ║\r\n");
    printf(  "║  #define ACCEL_OFF_X   %-8d          ║\r\n", oax);
    printf(  "║  #define ACCEL_OFF_Y   %-8d          ║\r\n", oay);
    printf(  "║  #define ACCEL_OFF_Z   %-8d          ║\r\n", oaz);
    printf(  "║                                          ║\r\n");
    printf(  "║  /* Mag hard-iron offsets */             ║\r\n");
    printf(  "║  #define MAG_OFF_X     %-8d          ║\r\n", omx);
    printf(  "║  #define MAG_OFF_Y     %-8d          ║\r\n", omy);
    printf(  "║  #define MAG_OFF_Z     %-8d          ║\r\n", omz);
    printf(  "║                                          ║\r\n");
    printf(  "║  /* Mag soft-iron scale Q8 */            ║\r\n");
    printf(  "║  #define MAG_SCALE_X   %-8d          ║\r\n", sx);
    printf(  "║  #define MAG_SCALE_Y   %-8d          ║\r\n", sy);
    printf(  "║  #define MAG_SCALE_Z   %-8d          ║\r\n", sz);
    printf(  "║                                          ║\r\n");
    printf(  "╚══════════════════════════════════════════╝\r\n");

    /* ── Section 4: Quality assessment ── */
    printf("\r\nQUALITY CHECK:\r\n");

    /* Accel offset quality */
    int accel_ok = (oax > -800 && oax < 800 &&
                    oay > -800 && oay < 800 &&
                    oaz > -800 && oaz < 800);
    printf("  Accel offsets : %s\r\n", accel_ok ? "GOOD" : "WARN — large offset, redo if unsure");

    /* Mag offset quality — offsets should be much smaller than full range */
    int mag_ok = (omx > -50000 && omx < 50000 &&
                  omy > -50000 && omy < 50000 &&
                  omz > -50000 && omz < 50000);
    printf("  Mag offsets   : %s\r\n", mag_ok ? "GOOD" : "WARN — very large, strong interference nearby");

    /* Scale quality — all should be close to 256 */
    int32_t sx_err = sx - 256; if (sx_err < 0) sx_err = -sx_err;
    int32_t sy_err = sy - 256; if (sy_err < 0) sy_err = -sy_err;
    int32_t sz_err = sz - 256; if (sz_err < 0) sz_err = -sz_err;
    int scale_ok = (sx_err < 77 && sy_err < 77 && sz_err < 77); /* <30% */
    printf("  Soft-iron     : %s\r\n", scale_ok ? "GOOD" :
           "WARN — >30%% distortion, motor magnets likely cause");

    printf("\r\nCalibration complete. Share these values\r\n");
    printf("to get mahony_cal.c with offsets applied.\r\n");
}

/* ═══════════════════════════════════════════════════════════════
 * main
 * ═══════════════════════════════════════════════════════════════ */
int main(void)
{
    init_uart();
    i2c_init(I2C_BUS);
    local_sleep(200000);

    printf("\r\n╔══════════════════════════════════════════╗\r\n");
    printf(  "║   TRISUL32 CALIBRATION TOOL              ║\r\n");
    printf(  "║   Mission Planner sequence               ║\r\n");
    printf(  "║   UART0: 0x10000100  I2C0                ║\r\n");
    printf(  "╚══════════════════════════════════════════╝\r\n\r\n");

    if (!ism330_init()) {
        printf("ERROR: ISM330DHCX not found at 0x%02X\r\n", ISM_ADDR);
        while (1);
    }
    printf("ISM330DHCX OK\r\n");

    if (!mmc5983_init()) {
        printf("ERROR: MMC5983MA not found at 0x%02X\r\n", MMC_ADDR);
        while (1);
    }
    printf("MMC5983MA OK\r\n");

    printf("\r\nMake sure motors are MOUNTED but NOT spinning\r\n");
    printf("Press Enter to begin calibration...\r\n");
    wait_for_enter();

    /* Shared mag min/max across both phases */
    int32_t mx_min= 2000000, mx_max=-2000000;
    int32_t my_min= 2000000, my_max=-2000000;
    int32_t mz_min= 2000000, mz_max=-2000000;

    /* Phase 1 — 6 still positions */
    int32_t off_ax, off_ay, off_az;
    phase1_still_positions(&off_ax, &off_ay, &off_az,
                           &mx_min, &mx_max,
                           &my_min, &my_max,
                           &mz_min, &mz_max);

    /* Phase 2 — rotation (adds more mag data to same min/max) */
    phase2_rotation(&mx_min, &mx_max,
                    &my_min, &my_max,
                    &mz_min, &mz_max);

    /* Compute mag offsets */
    int32_t off_mx, off_my, off_mz;
    int32_t sx, sy, sz;
    compute_mag_offsets(mx_min, mx_max,
                        my_min, my_max,
                        mz_min, mz_max,
                        &off_mx, &off_my, &off_mz,
                        &sx, &sy, &sz);

    /* Print results */
    print_results(off_ax, off_ay, off_az,
                  off_mx, off_my, off_mz,
                  sx, sy, sz);

    while (1);
    return 0;
}