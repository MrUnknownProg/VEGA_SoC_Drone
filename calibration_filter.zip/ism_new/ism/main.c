#include <stdint.h>
#include <stdio.h>
#include <math.h>
#include "i2c_api.h"
#include "include/debug_uart.h"

/* ═══════════════════════════════════════════════════════════════
 * 0. HARDWARE SHIM
 * ═══════════════════════════════════════════════════════════════ */
#define UART0_BASE        0x10000100UL
#define UART_DR           (*(volatile uint32_t *)(UART0_BASE + 0x00))
#define UART_LSR          (*(volatile uint32_t *)(UART0_BASE + 0x14))
#define UART_LSR_TX_EMPTY (1u << 5)

void tx_uart(unsigned char c) {
    while (!(UART_LSR & UART_LSR_TX_EMPTY));
    UART_DR = (uint32_t)c;
}

int _write(int fd, const char *buf, int count) {
    (void)fd;
    for (int i = 0; i < count; i++) {
        if (buf[i] == '\n') tx_uart('\r');
        tx_uart((unsigned char)buf[i]);
    }
    return count;
}

/* ═══════════════════════════════════════════════════════════════
 * 1. CALIBRATION CONSTANTS
 * ═══════════════════════════════════════════════════════════════ */
#define ACCEL_OFF_X    298
#define ACCEL_OFF_Y    -17
#define ACCEL_OFF_Z    -8

#define MAG_OFF_X      10
#define MAG_OFF_Y      -726
#define MAG_OFF_Z      -35

#define MAG_SCALE_X    228
#define MAG_SCALE_Y    276
#define MAG_SCALE_Z    268

// Timing for 40MHz Clock
#define DT 0.01f      // Target 100Hz (10ms)
#define RAD2DEG 57.29578f
#define DEG2RAD 0.0174533f

static float q[4] = {1.0f, 0.0f, 0.0f, 0.0f};
static float exInt = 0.0f, eyInt = 0.0f, ezInt = 0.0f;
static float gx_bias = 0.0f, gy_bias = 0.0f, gz_bias = 0.0f;

/* ═══════════════════════════════════════════════════════════════
 * 2. MODIFIED MAHONY FILTER (ACCEPTS DYNAMIC KP)
 * ═══════════════════════════════════════════════════════════════ */
static float inv_sqrt(float x) {
    float halfx = 0.5f * x;
    float y = x;
    long i = *(long*)&y;
    i = 0x5f3759df - (i >> 1);
    y = *(float*)&i;
    y = y * (1.5f - (halfx * y * y));
    return y;
}

static void mahony_update(float gx, float gy, float gz, float ax, float ay, float az, float mx, float my, float mz, float active_kp) {
    float recip;
    float q0 = q[0], q1 = q[1], q2 = q[2], q3 = q[3];
    float hx, hy, bx, bz, vx, vy, vz, wx, wy, wz, ex, ey, ez;

    float a_norm = ax*ax + ay*ay + az*az;
    if (a_norm > 0.001f) {
        recip = inv_sqrt(a_norm);
        ax *= recip; ay *= recip; az *= recip;
    } else return;

    float m_norm = mx*mx + my*my + mz*mz;
    if (m_norm > 0.001f) {
        recip = inv_sqrt(m_norm);
        mx *= recip; my *= recip; mz *= recip;
    }

    hx = 2.0f * (mx * (0.5f - q2*q2 - q3*q3) + my * (q1*q2 - q0*q3) + mz * (q1*q3 + q0*q2));
    hy = 2.0f * (mx * (q1*q2 + q0*q3) + my * (0.5f - q1*q1 - q3*q3) + mz * (q2*q3 - q0*q1));
    bx = sqrtf(hx*hx + hy*hy);
    bz = 2.0f * (mx * (q1*q3 - q0*q2) + my * (q2*q3 + q0*q1) + mz * (0.5f - q1*q1 - q2*q2));

    vx = 2.0f * (q1*q3 - q0*q2);
    vy = 2.0f * (q0*q1 + q2*q3);
    vz = q0*q0 - 0.5f + q3*q3;
    wx = 2.0f * (bx * (0.5f - q2*q2 - q3*q3) + bz * (q1*q3 - q0*q2));
    wy = 2.0f * (bx * (q1*q2 - q0*q3) + bz * (q0*q1 + q2*q3));
    wz = 2.0f * (bx * (q0*q2 + q1*q3) + bz * (0.5f - q1*q1 - q2*q2));

    ex = (ay*vz - az*vy) + (my*wz - mz*wy);
    ey = (az*vx - ax*vz) + (mz*wx - mx*wz);
    ez = (ax*vy - ay*vx) + (mx*wy - my*wx);

    exInt += ex * 0.005f * DT;
    eyInt += ey * 0.005f * DT;
    ezInt += ez * 0.005f * DT;

    gx += active_kp * ex + exInt;
    gy += active_kp * ey + eyInt;
    gz += active_kp * ez + ezInt;

    q[0] += (-q1*gx - q2*gy - q3*gz) * (0.5f * DT);
    q[1] += (q0*gx + q2*gz - q3*gy) * (0.5f * DT);
    q[2] += (q0*gy - q1*gz + q3*gx) * (0.5f * DT);
    q[3] += (q0*gz + q1*gy - q2*gx) * (0.5f * DT);

    recip = inv_sqrt(q[0]*q[0] + q[1]*q[1] + q[2]*q[2] + q[3]*q[3]);
    q[0] *= recip; q[1] *= recip; q[2] *= recip; q[3] *= recip;
}

/* ═══════════════════════════════════════════════════════════════
 * 3. MAIN LOOP
 * ═══════════════════════════════════════════════════════════════ */
int main(void) {
    i2c_init(0);
    
    // ISM330 and MMC5983 Initialization
    i2c_beginTransmission(0x6B); i2c_write(0x10); i2c_write(0x4A); i2c_endTransmission(1);
    i2c_beginTransmission(0x6B); i2c_write(0x11); i2c_write(0x4C); i2c_endTransmission(1);
    i2c_beginTransmission(0x30); i2c_write(0x09); i2c_write(0x08); i2c_endTransmission(1);

    // Initial Static Gyro Bias Calibration
    printf("\nCALIBRATING GYRO BIAS...\n");
    float sX=0, sY=0, sZ=0;
    for(int i=0; i<400; i++) {
        uint8_t r[6];
        i2c_beginTransmission(0x6B); i2c_write(0x22); i2c_endTransmission(1);
        if(i2c_requestFrom(0x6B, 6, 1)) {
            for(int j=0; j<6; j++) r[j]=i2c_read();
            sX += (int16_t)((r[1]<<8)|r[0]);
            sY += (int16_t)((r[3]<<8)|r[2]);
            sZ += (int16_t)((r[5]<<8)|r[4]);
        }
        for(volatile int d=0; d<2000; d++); 
    }
    gx_bias = (sX/400.0f) * 0.0175f * DEG2RAD;
    gy_bias = (sY/400.0f) * 0.0175f * DEG2RAD;
    gz_bias = (sZ/400.0f) * 0.0175f * DEG2RAD;

    float active_kp = 10.0f; // Start high to "lock" orientation
    uint32_t loop_cnt = 0;

    while (1) {
        uint8_t raw[12];
        int32_t mx_raw, my_raw, mz_raw;

        // Switch KP after convergence (~500 loops = ~5 seconds)
        if (loop_cnt == 500) {
            active_kp = 2.0f;
            printf("\n[SYSTEM] Converged. Switching to Flight Gain (Kp=1.5)\n");
        }

        // 1. Read IMU
        i2c_beginTransmission(0x6B); i2c_write(0x22); i2c_endTransmission(1);
        if (i2c_requestFrom(0x6B, 12, 1)) {
            for(int i=0; i<12; i++) raw[i] = i2c_read();
        }

        // 2. Read Mag (Trigger TM_M)
        i2c_beginTransmission(0x30); i2c_write(0x09); i2c_write(0x01); i2c_endTransmission(1);
        for(volatile int d=0; d<4000; d++); // Mag conversion delay
        i2c_beginTransmission(0x30); i2c_write(0x00); i2c_endTransmission(1);
        if (i2c_requestFrom(0x30, 6, 1)) {
            uint8_t mb[6];
            for(int i=0; i<6; i++) mb[i] = i2c_read();
            mx_raw = (int32_t)((mb[0]<<8)|mb[1]) - 32768;
            my_raw = (int32_t)((mb[2]<<8)|mb[3]) - 32768;
            mz_raw = (int32_t)((mb[4]<<8)|mb[5]) - 32768;
        }

        // 3. Scale Data
        float ax = ((int16_t)((raw[7]<<8)|raw[6]) - ACCEL_OFF_X) / 8192.0f;
        float ay = ((int16_t)((raw[9]<<8)|raw[8]) - ACCEL_OFF_Y) / 8192.0f;
        float az = ((int16_t)((raw[11]<<8)|raw[10]) - ACCEL_OFF_Z) / 8192.0f;
        float gx = ((int16_t)((raw[1]<<8)|raw[0]) * 0.0175f * DEG2RAD) - gx_bias;
        float gy = ((int16_t)((raw[3]<<8)|raw[2]) * 0.0175f * DEG2RAD) - gy_bias;
        float gz = ((int16_t)((raw[5]<<8)|raw[4]) * 0.0175f * DEG2RAD) - gz_bias;
        float mx = (float)((mx_raw - MAG_OFF_X) * MAG_SCALE_X) / 256.0f;
        float my = (float)((my_raw - MAG_OFF_Y) * MAG_SCALE_Y) / 256.0f;
        float mz = (float)((mz_raw - MAG_OFF_Z) * MAG_SCALE_Z) / 256.0f;

        // 4. Update Filter with dynamic KP
        mahony_update(gx, gy, gz, ax, ay, az, mx, my, mz, active_kp);

        // 5. Output
        if (loop_cnt % 25 == 0) {
            float r = atan2f(2*(q[0]*q[1]+q[2]*q[3]), 1-2*(q[1]*q[1]+q[2]*q[2])) * RAD2DEG;
            float p = asinf(2*(q[0]*q[2]-q[3]*q[1])) * RAD2DEG;
            float y = atan2f(2*(q[0]*q[3]+q[1]*q[2]), 1-2*(q[2]*q[2]+q[3]*q[3])) * RAD2DEG;
            printf("R:%d P:%d Y:%d (Kp:%.1f)\n", (int)r, (int)p, (int)y, active_kp);
        }

        loop_cnt++;
        // Delay loop for 40MHz core. This aims for ~10ms loop time.
        // If your output is too slow, decrease this number.
        for(volatile int d=0; d<3500; d++); 
    }
}